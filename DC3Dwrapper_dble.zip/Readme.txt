This is a fix for the Matlab Okada wrapper for DC3D.f (in which the source point can be at depth), when I try to use it on my macbook pro 2015.

Some information about my system, it is Catalina 10.15.7, Matlab R2020a, ifort version 19.1.2.258.

With teh original version, I kept getting segmentation error when I try to run the function after mex. I found that it is because the mex on my machine doesn't like the precision conversion. To solve it, I made all the float variable in both the mex file (.F) and the fortran source code (.f) double float. And this solution works for me.

Every steps to mex the fortran function are the same as before. I simply do 

mex 'DC3Dwrapper.F'

My matlab cannot automatically detect ifortran, so I need to do this before I run mex

setenv('PATH', [getenv('PATH') ':/opt/intel/compilers_and_libraries_2020.2.258/mac/bin/intel64:/opt/intel/compilers_and_libraries_2020.2.258/mac/bin:/opt/intel//debugger_2020/gdb/intel64/bin:']);

You may need to change your ifortran Path accordingly

Baoning Wu
2022.01.19